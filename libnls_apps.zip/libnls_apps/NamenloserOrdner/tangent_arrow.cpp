#include<cmath>
#include<iostream>
#include<vector>

#define DCO_AUTO_SUPPORT
#define DCO_DISABLE_AVX2_WARNING
#include "dco.hpp"

#include "ColPackHeaders.h"
#include "GraphColoringInterface.h"
#include "RecoveryCore.h"

//using namespace ColPack;
using namespace std;

typedef dco::gt1s<double>::type ad_type;

template<class T>
void f(vector<T>& x, vector<T>& y){
    const int n = x.size();
    for(int i = 0; i < n;i++){
        y[i] = 2*x[0] + x[i];
    }
}

int main(){
    const int n = 10;

    vector<ad_type> x(n);
    vector<ad_type> y(n);

    for(int i = 0; i < n;i++){
        x[i] = i+1;
    }

    // we know the sparsity pattern here
    int maxNumberOfNonzerosPerRow=2;
    // allocate memory for SparseCompressedRow format
    unsigned int** colPackSparsityPattern = new unsigned int*[n];
    for (int i = 0; i < n; i++){
        colPackSparsityPattern[i] = new unsigned int[maxNumberOfNonzerosPerRow+1];
        colPackSparsityPattern[i][0] = 2; // two non zeroes per row
        colPackSparsityPattern[i][1] = 0; // first non zero in column 0
        colPackSparsityPattern[i][2] = i; // second non zero in column 1
    }

    // color, should give two colors
    ColPack::BipartiteGraphPartialColoringInterface g(SRC_MEM_ADOLC, colPackSparsityPattern, n, n);
    g.PartialDistanceTwoColoring("NATURAL", "COLUMN_PARTIAL_DISTANCE_TWO");

    // get seed matrix
    int seedRowCount, seedColCount;
    double** colPackSeedMatrix = g.GetSeedMatrix(&seedRowCount, &seedColCount);

    g.PrintColumnPartialColoringMetrics();

    // compute compressed Jacobian \in R^{n x 2}
    double** compressedJacobian = new double*[n];
    for (int i = 0; i < n; i++)
        compressedJacobian[i] = new double[seedColCount];

    for(int i = 0; i < seedColCount; i++) {
        for(int j = 0; j < seedRowCount; j++){
            dco::derivative(x[j]) = colPackSeedMatrix[j][i];
        }
        f(x,y);
        for(int j = 0; j < seedRowCount; j++) {
            compressedJacobian[j][i] = dco::derivative(y[j]);
        }
    }

    // Recover Full Jacobian
    vector<std::vector<double>> fullJac(n,std::vector<double>(n,0.0));
    ColPack::JacobianRecovery1D jr1d;
    unsigned int* rowIndex;
    unsigned int* colIndex;
    double* jacValue;
    int nnz = jr1d.RecoverD2Cln_CoordinateFormat(&g, compressedJacobian, colPackSparsityPattern, &rowIndex, &colIndex, &jacValue);
    for(int i = 0; i < nnz; i++){
        fullJac[rowIndex[i]][colIndex[i]] = jacValue[i];
    }
    for(int i=0; i<n; i++){
        for(int j=0; j<n; j++){
            std::cout << fullJac[i][j] << " ";
        }
        std::cout << std::endl;
    }

    // cleanup
    for(int i = 0; i < n; i++){
        delete[] colPackSparsityPattern[i];
        delete[] compressedJacobian[i];
    }
    delete[] colPackSparsityPattern;
    delete[] compressedJacobian;

    // rowIndex, colIndex, jacValue deallocated by ColPack
}

